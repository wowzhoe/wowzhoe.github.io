self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cadb2e0d9ddce37fff43a008250b4085",
    "url": "/index.html"
  },
  {
    "revision": "fa18631b80c09bab24f7",
    "url": "/static/css/2.60d54493.chunk.css"
  },
  {
    "revision": "8e99f14164508a1ec689",
    "url": "/static/css/main.1a304493.chunk.css"
  },
  {
    "revision": "fa18631b80c09bab24f7",
    "url": "/static/js/2.18bfe34b.chunk.js"
  },
  {
    "revision": "8e99f14164508a1ec689",
    "url": "/static/js/main.32192abe.chunk.js"
  },
  {
    "revision": "cb881929f9b11f89a746",
    "url": "/static/js/runtime~main.d0befee9.js"
  },
  {
    "revision": "3440b60515f3e9b38279956ce0bd3e52",
    "url": "/static/media/Metropolis-Regular.3440b605.ttf"
  },
  {
    "revision": "4a405762789758475f736592772ebfd1",
    "url": "/static/media/Metropolis-Regular.4a405762.woff2"
  },
  {
    "revision": "9f2131c2974ff6dcfefe82f5727c466d",
    "url": "/static/media/background.9f2131c2.svg"
  },
  {
    "revision": "7bd9a61f8f1ba09b4d7f957d243470d7",
    "url": "/static/media/compass.7bd9a61f.svg"
  },
  {
    "revision": "adb137f0fa13eb025c13d13c727fe7fa",
    "url": "/static/media/grab.adb137f0.svg"
  },
  {
    "revision": "3acfddd5c09c90a4f089f8d626aebca1",
    "url": "/static/media/grabbing.3acfddd5.svg"
  },
  {
    "revision": "f37aa8ca72b5548a255c62dab1614437",
    "url": "/static/media/sprites.f37aa8ca.svg"
  }
]);