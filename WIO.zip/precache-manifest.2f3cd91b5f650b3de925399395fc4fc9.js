self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d71121f16ee0a25b9c1181da5263b491",
    "url": "/index.html"
  },
  {
    "revision": "923baaa6c7d9c852bf04",
    "url": "/static/css/2.eba890c0.chunk.css"
  },
  {
    "revision": "c61de1c6ece0a859272e",
    "url": "/static/css/main.f1e43b74.chunk.css"
  },
  {
    "revision": "923baaa6c7d9c852bf04",
    "url": "/static/js/2.3f10e8b4.chunk.js"
  },
  {
    "revision": "c61de1c6ece0a859272e",
    "url": "/static/js/main.a79c375c.chunk.js"
  },
  {
    "revision": "67e9620f052021d31c32",
    "url": "/static/js/runtime~main.642c07d4.js"
  },
  {
    "revision": "3440b60515f3e9b38279956ce0bd3e52",
    "url": "/static/media/Metropolis-Regular.3440b605.ttf"
  },
  {
    "revision": "4a405762789758475f736592772ebfd1",
    "url": "/static/media/Metropolis-Regular.4a405762.woff2"
  },
  {
    "revision": "9f2131c2974ff6dcfefe82f5727c466d",
    "url": "/static/media/background.9f2131c2.svg"
  },
  {
    "revision": "7bd9a61f8f1ba09b4d7f957d243470d7",
    "url": "/static/media/compass.7bd9a61f.svg"
  },
  {
    "revision": "adb137f0fa13eb025c13d13c727fe7fa",
    "url": "/static/media/grab.adb137f0.svg"
  },
  {
    "revision": "3acfddd5c09c90a4f089f8d626aebca1",
    "url": "/static/media/grabbing.3acfddd5.svg"
  },
  {
    "revision": "845e2c2a7b533b2103aac0d5222ca330",
    "url": "/static/media/logo.845e2c2a.png"
  },
  {
    "revision": "f37aa8ca72b5548a255c62dab1614437",
    "url": "/static/media/sprites.f37aa8ca.svg"
  }
]);